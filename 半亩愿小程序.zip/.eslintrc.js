module.exports = {
  root: true,
  env: {
    browser: true,
    es6: true,
    node: true,
    commonjs: true,
  },
  parserOptions: {
    ecmaVersion: 2018,
    sourceType: 'module',
  },
  globals: {
    wx: 'readonly',
    App: 'readonly',
    Page: 'readonly',
    Component: 'readonly',
    getApp: 'readonly',
    getCurrentPages: 'readonly',
  },
  rules: {
    // 允许 console
    'no-console': 'off',
    // 允许未使用的变量（有时是为了保持接口一致性）
    'no-unused-vars': 'off',
    // 允许空函数（有时作为回调占位）
    'no-empty-function': 'off',
    // 允许未定义的变量（因为有 wx 等全局变量）
    'no-undef': 'off',
  },
};
