/**
 * 数据库操作辅助函数
 * 用于愿望清单小程序的数据操作
 */

import { DefaultCategories } from '../types/dataTypes.js';

/**
 * 创建默认分类
 * @param {string} pairId - 配对ID
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Array>} 创建的分类列表
 */
export async function createDefaultCategories(pairId, db) {
  const categories = DefaultCategories.map(cat => ({
    pairId,
    name: cat.name,
    type: cat.type,
    icon: cat.icon,
    color: cat.color,
    sort: cat.sort,
    createTime: new Date(),
    updateTime: new Date()
  }));

  // 批量插入分类
  const result = await db.collection('category').add({
    data: categories
  });

  return result;
}

/**
 * 创建愿望项
 * @param {Object} wishItemData - 愿望项数据
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Object>} 创建结果
 */
export async function createWishItem(wishItemData, db) {
  const data = {
    ...wishItemData,
    status: wishItemData.status || 'pending',
    isCompleted: false,
    createTime: new Date(),
    updateTime: new Date()
  };

  return await db.collection('wishItem').add({
    data
  });
}

/**
 * 更新愿望项状态为已完成
 * @param {string} wishItemId - 愿望项ID
 * @param {string} userId - 完成者用户ID
 * @param {string} userName - 完成者昵称
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Object>} 更新结果
 */
export async function completeWishItem(wishItemId, userId, userName, db) {
  const now = new Date();
  return await db.collection('wishItem').doc(wishItemId).update({
    data: {
      status: 'completed',
      isCompleted: true,
      completedTime: now,
      actualDate: now,
      actualTime: `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`,
      completedBy: userId,
      completedByName: userName,
      updateTime: now
    }
  });
}

/**
 * 获取配对的愿望项列表
 * @param {string} pairId - 配对ID
 * @param {Object} options - 查询选项
 * @param {string} [options.categoryId] - 分类ID（可选）
 * @param {boolean} [options.isCompleted] - 是否已完成（可选）
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Array>} 愿望项列表
 */
export async function getWishItems(pairId, options = {}, db) {
  let query = db.collection('wishItem').where({
    pairId
  });

  if (options.categoryId) {
    query = query.where({
      categoryId: options.categoryId
    });
  }

  if (options.isCompleted !== undefined) {
    query = query.where({
      isCompleted: options.isCompleted
    });
  }

  // 排序
  const orderBy = options.isCompleted ? 'completedTime' : 'createTime';
  const order = options.isCompleted ? 'desc' : 'desc';

  const result = await query
    .orderBy(orderBy, order)
    .get();

  return result.data;
}

/**
 * 获取配对的分类列表
 * @param {string} pairId - 配对ID
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Array>} 分类列表
 */
export async function getCategories(pairId, db) {
  const result = await db.collection('category')
    .where({
      pairId
    })
    .orderBy('sort', 'asc')
    .get();

  return result.data;
}

/**
 * 创建配对关系
 * @param {string} user1Id - 用户1 ID
 * @param {Object} user1Info - 用户1信息
 * @param {string} user2Id - 用户2 ID
 * @param {Object} user2Info - 用户2信息
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Object>} 创建结果
 */
export async function createPair(user1Id, user1Info, user2Id, user2Info, db) {
  // 生成配对码（6位随机数字）
  const pairCode = Math.floor(100000 + Math.random() * 900000).toString();

  const pairData = {
    user1Id,
    user2Id,
    user1Info: {
      userId: user1Id,
      nickname: user1Info.nickname,
      avatar: user1Info.avatar
    },
    user2Info: {
      userId: user2Id,
      nickname: user2Info.nickname,
      avatar: user2Info.avatar
    },
    pairCode,
    status: 'active',
    createTime: new Date(),
    updateTime: new Date()
  };

  const result = await db.collection('pair').add({
    data: pairData
  });

  // 创建默认分类
  await createDefaultCategories(result._id, db);

  return {
    ...pairData,
    _id: result._id
  };
}

/**
 * 通过配对码查找配对
 * @param {string} pairCode - 配对码
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Object|null>} 配对信息
 */
export async function findPairByCode(pairCode, db) {
  const result = await db.collection('pair')
    .where({
      pairCode,
      status: 'active'
    })
    .get();

  return result.data.length > 0 ? result.data[0] : null;
}

/**
 * 获取用户的配对列表
 * @param {string} userId - 用户ID
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Array>} 配对列表
 */
export async function getUserPairs(userId, db) {
  const result = await db.collection('pair')
    .where({
      _openid: userId, // 或者使用 user1Id 或 user2Id
      status: 'active'
    })
    .get();

  return result.data;
}

/**
 * 统计配对的愿望项数据
 * @param {string} pairId - 配对ID
 * @param {Function} db - 云数据库实例
 * @returns {Promise<Object>} 统计数据
 */
export async function getPairStatistics(pairId, db) {
  // 获取所有愿望项
  const allItems = await db.collection('wishItem')
    .where({
      pairId
    })
    .get();

  const items = allItems.data;
  const totalItems = items.length;
  const completedItems = items.filter(item => item.isCompleted).length;
  const pendingItems = totalItems - completedItems;

  // 按分类统计
  const categories = await getCategories(pairId, db);
  const byCategory = {};

  categories.forEach(category => {
    const categoryItems = items.filter(item => item.categoryId === category._id);
    byCategory[category._id] = {
      total: categoryItems.length,
      completed: categoryItems.filter(item => item.isCompleted).length,
      pending: categoryItems.filter(item => !item.isCompleted).length
    };
  });

  return {
    totalItems,
    completedItems,
    pendingItems,
    completionRate: totalItems > 0 ? (completedItems / totalItems * 100).toFixed(2) : 0,
    byCategory
  };
}
