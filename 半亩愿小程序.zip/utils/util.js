const formatNumber = (n) => {
  n = n.toString();
  return n[1] ? n : `0${n}`;
};

export const formatTime = (date) => {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hour = date.getHours();
  const minute = date.getMinutes();
  const second = date.getSeconds();

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`;
};

// 复制到本地临时路径，方便预览
export const getLocalUrl = (path, name) => {
  const fs = wx.getFileSystemManager();
  const tempFileName = `${wx.env.USER_DATA_PATH}/${name}`;
  fs.copyFileSync(path, tempFileName);
  return tempFileName;
};

/**
 * 保存图片到永久位置
 * 将临时文件复制到 USER_DATA_PATH，确保图片不会因为临时路径失效而丢失
 * @param {string} tempFilePath - 临时文件路径（可能是本地路径或 http://127.0.0.1 格式）
 * @returns {Promise<string>} 永久文件路径
 */
export const saveImageToPermanent = (tempFilePath) => {
  return new Promise((resolve, reject) => {
    try {
      const fs = wx.getFileSystemManager();
      
      // 如果是网络路径（http://127.0.0.1），无法直接复制，返回原路径
      if (tempFilePath && tempFilePath.startsWith('http://')) {
        console.warn('网络路径无法保存到本地:', tempFilePath);
        resolve(tempFilePath);
        return;
      }
      
      // 检查文件是否存在
      try {
        fs.accessSync(tempFilePath);
      } catch (err) {
        console.warn('文件不存在，无法保存:', tempFilePath);
        resolve(tempFilePath);
        return;
      }
      
      // 生成唯一的文件名（使用时间戳 + 随机数）
      const timestamp = Date.now();
      const random = Math.random().toString(36).substring(2, 9);
      const lastDotIndex = tempFilePath.lastIndexOf('.');
      const ext = lastDotIndex > 0 ? tempFilePath.substring(lastDotIndex) : '.jpg';
      const fileName = `wish_image_${timestamp}_${random}${ext}`;
      const permanentPath = `${wx.env.USER_DATA_PATH}/${fileName}`;
      
      // 复制文件到永久位置
      fs.copyFile({
        srcPath: tempFilePath,
        destPath: permanentPath,
        success: () => {
          console.log('图片已保存到永久位置:', permanentPath);
          resolve(permanentPath);
        },
        fail: (err) => {
          console.error('保存图片失败:', err);
          // 如果复制失败，返回原路径
          resolve(tempFilePath);
        }
      });
    } catch (error) {
      console.error('保存图片异常:', error);
      // 发生异常时返回原路径
      resolve(tempFilePath);
    }
  });
};


/**
 * 检查是否为临时路径
 * @param {string} imagePath - 图片路径
 * @returns {boolean} 是否为临时路径
 */
export const isTempImagePath = (imagePath) => {
  if (!imagePath) return false;
  
  const coverImage = String(imagePath).trim();
  
  // 使用正则表达式严格匹配临时路径
  return /__tmp__/.test(coverImage) || 
         /^http:\/\/127\.0\.0\.1/.test(coverImage) ||
         coverImage.includes('http://127.0.0.1');
};
