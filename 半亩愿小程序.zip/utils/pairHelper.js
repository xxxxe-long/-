/**
 * 配对管理工具函数
 */

/**
 * 生成6位邀请码（字母数字组合）
 * @returns {string} 邀请码
 */
export function generateInvitationCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 排除容易混淆的字符：0, O, I, 1
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

/**
 * 验证邀请码格式
 * @param {string} code - 邀请码
 * @returns {boolean} 是否有效
 */
export function validateInvitationCode(code) {
  if (!code || typeof code !== 'string') {
    return false;
  }
  // 6位字母数字组合
  const pattern = /^[A-Z0-9]{6}$/;
  return pattern.test(code.toUpperCase());
}

/**
 * 格式化邀请码（转换为大写，去除空格）
 * @param {string} code - 原始邀请码
 * @returns {string} 格式化后的邀请码
 */
export function formatInvitationCode(code) {
  if (!code || typeof code !== 'string') {
    return '';
  }
  return code.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
}

/**
 * 从本地存储获取配对信息
 * @returns {Object|null} 配对信息
 */
export function getPairInfoFromStorage() {
  try {
    const data = wx.getStorageSync('pair_info');
    return data || null;
  } catch (error) {
    console.error('读取配对信息失败:', error);
    return null;
  }
}

/**
 * 保存配对信息到本地存储
 * @param {Object} pairInfo - 配对信息
 * @returns {boolean} 是否成功
 */
export function savePairInfoToStorage(pairInfo) {
  try {
    wx.setStorageSync('pair_info', pairInfo);
    return true;
  } catch (error) {
    console.error('保存配对信息失败:', error);
    return false;
  }
}

/**
 * 清除本地存储的配对信息
 * @returns {boolean} 是否成功
 */
export function clearPairInfoFromStorage() {
  try {
    wx.removeStorageSync('pair_info');
    return true;
  } catch (error) {
    console.error('清除配对信息失败:', error);
    return false;
  }
}

/**
 * 获取当前用户的配对ID
 * @returns {string|null} 配对ID
 */
export function getCurrentPairId() {
  const pairInfo = getPairInfoFromStorage();
  return pairInfo?.pairId || null;
}

/**
 * 检查是否已配对
 * @returns {boolean} 是否已配对
 */
export function isPaired() {
  const pairInfo = getPairInfoFromStorage();
  return pairInfo && pairInfo.hasPair && pairInfo.status === 'active';
}
