/**
 * 分类管理工具函数
 */

import { DefaultCategories } from '~/types/dataTypes';

// 本地存储键名
const STORAGE_KEY = 'customCategories';
const COLOR_OVERRIDE_KEY = 'category_color_overrides'; // 分类颜色覆盖（包括默认分类）
const CATEGORY_ORDER_KEY = 'category_custom_order'; // 分类排序顺序

/**
 * 获取分类颜色覆盖映射
 */
function getColorOverrides() {
  try {
    const data = wx.getStorageSync(COLOR_OVERRIDE_KEY);
    return data || {};
  } catch (error) {
    console.error('读取颜色覆盖失败:', error);
    return {};
  }
}

/**
 * 保存分类颜色覆盖映射
 */
function saveColorOverrides(overrides) {
  try {
    wx.setStorageSync(COLOR_OVERRIDE_KEY, overrides);
    return true;
  } catch (error) {
    console.error('保存颜色覆盖失败:', error);
    return false;
  }
}

/**
 * 预设颜色列表（用于统计页颜色选择和新建分类）
 */
export const PresetColors = [
  { value: '#FF6B6B', name: '红色' },
  { value: '#FF8C42', name: '橙红' },
  { value: '#FFD93D', name: '黄色' },
  { value: '#52C41A', name: '绿色' },
  { value: '#00CEC9', name: '青色' },
  { value: '#4A90E2', name: '蓝色' },
  { value: '#9B59B6', name: '紫色' },
  { value: '#E91E63', name: '粉红' },
  { value: '#FF6B9D', name: '玫粉' },
  { value: '#C44569', name: '紫红' },
  { value: '#6C5CE7', name: '深紫' },
  { value: '#A29BFE', name: '淡紫' },
  { value: '#00B894', name: '深绿' },
  { value: '#FDCB6E', name: '金黄' },
  { value: '#E17055', name: '橙色' },
  { value: '#DDA0DD', name: '梅红' },
  { value: '#98D8C8', name: '薄荷' },
  { value: '#F7DC6F', name: '柠檬' },
];

/**
 * 获取所有分类（包含默认分类和自定义分类）
 * 注意：此函数会被 updateCategoryColor 调用，需要避免循环依赖
 */
export function getAllCategories(skipColorOverrides = false) {
  const colorOverrides = skipColorOverrides ? {} : getColorOverrides();
  
  const defaultCategories = DefaultCategories.map(cat => {
    const categoryId = `cat_${cat.type}`;
    // 如果有颜色覆盖，使用覆盖颜色
    const overrideColor = colorOverrides[categoryId] || colorOverrides[cat.name];
    return {
      ...cat,
      _id: categoryId,
      color: overrideColor || cat.color, // 优先使用覆盖颜色
      createTime: new Date(0).toISOString(), // 默认分类使用最早时间
    };
  });
  
  const customCategories = getCustomCategories().map(cat => {
    // 自定义分类也支持颜色覆盖
    const overrideColor = colorOverrides[cat._id] || colorOverrides[cat.name];
    return {
      ...cat,
      color: overrideColor || cat.color, // 优先使用覆盖颜色
    };
  });
  
  // 合并所有分类
  const allCategories = [...defaultCategories, ...customCategories];
  
  // 检查是否有自定义顺序
  const customOrder = getCategoryOrder();
  
  // 排序逻辑
  return allCategories.sort((a, b) => {
    // 如果有自定义顺序，优先使用
    if (customOrder && customOrder.length > 0) {
      const aIndex = customOrder.indexOf(a._id);
      const bIndex = customOrder.indexOf(b._id);
      
      if (aIndex !== -1 && bIndex !== -1) {
        return aIndex - bIndex;
      } else if (aIndex !== -1) {
        return -1;
      } else if (bIndex !== -1) {
        return 1;
      }
    }

    // 回退到原始排序逻辑：默认分类按 sort 排序，自定义分类按创建时间排序
    // 如果是默认分类（没有 createTime 或 createTime 很早），按 sort 排序
    const aIsDefault = !a.createTime || new Date(a.createTime).getTime() === new Date(0).getTime();
    const bIsDefault = !b.createTime || new Date(b.createTime).getTime() === new Date(0).getTime();
    
    if (aIsDefault && bIsDefault) {
      // 都是默认分类，按 sort 排序
      return (a.sort || 999) - (b.sort || 999);
    } else if (aIsDefault) {
      // a 是默认分类，排在前面
      return -1;
    } else if (bIsDefault) {
      // b 是默认分类，排在前面
      return 1;
    } else {
      // 都是自定义分类，按创建时间排序（早的在前）
      return new Date(a.createTime || 0) - new Date(b.createTime || 0);
    }
  });
}

/**
 * 保存分类顺序
 */
export function saveCategoryOrder(orderIds) {
  try {
    const orderData = {
      order: orderIds,
      updatedAt: new Date().toISOString()
    };
    wx.setStorageSync(CATEGORY_ORDER_KEY, orderData);
    return true;
  } catch (error) {
    console.error('保存分类顺序失败:', error);
    return false;
  }
}

/**
 * 获取分类顺序
 */
export function getCategoryOrder() {
  try {
    const data = wx.getStorageSync(CATEGORY_ORDER_KEY);
    return data ? data.order : null;
  } catch (error) {
    console.error('读取分类顺序失败:', error);
    return null;
  }
}

/**
 * 获取分类顺序完整数据（含时间戳）
 */
export function getCategoryOrderFull() {
  try {
    return wx.getStorageSync(CATEGORY_ORDER_KEY) || { order: [], updatedAt: new Date(0).toISOString() };
  } catch (error) {
    return { order: [], updatedAt: new Date(0).toISOString() };
  }
}

/**
 * 获取自定义分类
 */
export function getCustomCategories() {
  try {
    const data = wx.getStorageSync(STORAGE_KEY) || [];
    // 在普通查询中过滤掉已删除的
    return data.filter(cat => !cat.isDeleted);
  } catch (error) {
    console.error('读取自定义分类失败:', error);
    return [];
  }
}

/**
 * 获取所有自定义分类（包含已删除，用于同步）
 */
export function getCustomCategoriesRaw() {
  try {
    return wx.getStorageSync(STORAGE_KEY) || [];
  } catch (error) {
    return [];
  }
}

/**
 * 保存自定义分类
 */
export function saveCustomCategories(categories) {
  try {
    wx.setStorageSync(STORAGE_KEY, categories);
    return true;
  } catch (error) {
    console.error('保存自定义分类失败:', error);
    return false;
  }
}

/**
 * 更新分类颜色（支持默认分类和自定义分类）
 * @param {string} categoryIdOrName - 分类ID（如 cat_dining）或分类名称
 * @param {string} color - 新颜色
 */
export function updateCategoryColor(categoryIdOrName, color) {
  const colorOverrides = getColorOverrides();
  
  // 尝试通过分类ID或名称查找分类
  // 注意：避免循环依赖，跳过颜色覆盖来获取原始分类信息
  const allCategories = getAllCategories(true);
  let targetCategory = null;
  
  // 先尝试通过ID匹配
  targetCategory = allCategories.find(cat => cat._id === categoryIdOrName);
  // 如果没找到，尝试通过名称匹配
  if (!targetCategory) {
    targetCategory = allCategories.find(cat => cat.name === categoryIdOrName);
  }
  
  if (!targetCategory) {
    console.warn('未找到分类:', categoryIdOrName);
    return false;
  }
  
  // 更新颜色覆盖映射（使用ID和名称作为key，确保都能找到）
  const categoryId = targetCategory._id;
  const categoryName = targetCategory.name;
  
  colorOverrides[categoryId] = color;
  colorOverrides[categoryName] = color;
  
  // 如果是自定义分类，同时更新分类数据本身
  if (targetCategory.type === 'custom') {
    const customCategories = getCustomCategories();
    const updatedCategories = customCategories.map(cat => {
      if (cat._id === categoryId || cat.name === categoryName) {
        return {
          ...cat,
          color: color,
          updateTime: new Date().toISOString(),
        };
      }
      return cat;
    });
    saveCustomCategories(updatedCategories);
  }
  
  // 保存颜色覆盖
  saveColorOverrides(colorOverrides);
  return true;
}

/**
 * 添加自定义分类
 */
export function addCustomCategory(category) {
  const customCategories = getCustomCategories();
  
  // 生成唯一ID
  const categoryId = `cat_custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // 使用统一的预设颜色
  const availableColors = PresetColors.map(c => c.value);
  
  // 如果用户指定了颜色，使用用户指定的颜色；否则从可用颜色中选择
  // 选择与已有分类颜色差异最大的颜色
  const allCategories = getAllCategories();
  const usedColors = allCategories.map(cat => cat.color).filter(Boolean);
  
  let selectedColor = category.color;
  if (!selectedColor) {
    // 找出与已使用颜色差异最大的颜色
    const colorDiff = (color1, color2) => {
      const hex1 = color1.replace('#', '');
      const hex2 = color2.replace('#', '');
      const r1 = parseInt(hex1.substr(0, 2), 16);
      const g1 = parseInt(hex1.substr(2, 2), 16);
      const b1 = parseInt(hex1.substr(4, 2), 16);
      const r2 = parseInt(hex2.substr(0, 2), 16);
      const g2 = parseInt(hex2.substr(2, 2), 16);
      const b2 = parseInt(hex2.substr(4, 2), 16);
      return Math.sqrt(Math.pow(r1 - r2, 2) + Math.pow(g1 - g2, 2) + Math.pow(b1 - b2, 2));
    };
    
    // 计算每个可用颜色与所有已使用颜色的最小差异
    let maxMinDiff = 0;
    let bestColor = availableColors[0];
    
    availableColors.forEach(color => {
      if (usedColors.includes(color)) return; // 跳过已使用的颜色
      
      const minDiff = Math.min(...usedColors.map(usedColor => colorDiff(color, usedColor)));
      if (minDiff > maxMinDiff) {
        maxMinDiff = minDiff;
        bestColor = color;
      }
    });
    
    selectedColor = bestColor;
  }
  
  const newCategory = {
    _id: categoryId,
    name: category.name,
    type: 'custom',
    icon: category.icon || '📝',
    color: selectedColor,
    sort: customCategories.length + DefaultCategories.length + 1,
    createdBy: wx.getStorageSync('pair_info')?.myInfo?.uid || 'me',
    createTime: new Date().toISOString(),
    updateTime: new Date().toISOString(),
  };
  
  customCategories.push(newCategory);
  saveCustomCategories(customCategories);
  
  return newCategory;
}

/**
 * 更新自定义分类
 */
export function updateCustomCategory(categoryId, category) {
  const customCategories = getCustomCategories();
  const updatedCategories = customCategories.map(cat => {
    if (cat._id === categoryId) {
      return {
        ...cat,
        ...category,
        updateTime: new Date().toISOString(),
      };
    }
    return cat;
  });
  saveCustomCategories(updatedCategories);
  return true;
}

/**
 * 删除自定义分类
 */
export function deleteCustomCategory(categoryId) {
  const customCategories = getCustomCategories();
  const updatedCategories = customCategories.map(cat => {
    if (cat._id === categoryId) {
      return {
        ...cat,
        isDeleted: true,
        updateTime: new Date().toISOString()
      };
    }
    return cat;
  });
  saveCustomCategories(updatedCategories);
  
  // 同时从排序顺序中移除
  const customOrder = getCategoryOrder();
  if (customOrder && customOrder.includes(categoryId)) {
    const newOrder = customOrder.filter(id => id !== categoryId);
    saveCategoryOrder(newOrder);
  }
  
  return true;
}

/**
 * 获取所有分类（包含已删除的，用于同步）
 */
export function getCustomCategoriesWithDeleted() {
  return getCustomCategories();
}

/**
 * 同步分类数据（Last Write Wins）
 * @param {Array} remoteCategories 远程分类列表
 */
export function syncCategories(remoteCategories) {
  if (!Array.isArray(remoteCategories)) return false;
  
  const localCategories = getCustomCategoriesRaw();
  const mergedMap = new Map();
  
  // 先放本地的
  localCategories.forEach(cat => mergedMap.set(cat._id, cat));
  
  // 再用远程的合并
  remoteCategories.forEach(remoteCat => {
    const localCat = mergedMap.get(remoteCat._id);
    if (!localCat || new Date(remoteCat.updateTime) > new Date(localCat.updateTime)) {
      mergedMap.set(remoteCat._id, remoteCat);
    }
  });
  
  const finalCategories = Array.from(mergedMap.values());
  saveCustomCategories(finalCategories);
  return true;
}

/**
 * 同步分类顺序（Last Write Wins）
 */
export function syncCategoryOrder(remoteOrderData) {
  if (!remoteOrderData || !remoteOrderData.updatedAt) return false;
  
  const localOrderData = getCategoryOrderFull();
  if (new Date(remoteOrderData.updatedAt) > new Date(localOrderData.updatedAt)) {
    wx.setStorageSync(CATEGORY_ORDER_KEY, remoteOrderData);
    return true;
  }
  return false;
}

/**
 * 根据 categoryId 获取分类信息
 */
export function getCategoryById(categoryId) {
  const allCategories = getAllCategories();
  return allCategories.find(cat => {
    // 处理默认分类的ID格式（cat_dining, cat_attraction等）
    if (categoryId.startsWith('cat_')) {
      const type = categoryId.replace('cat_', '');
      return cat.type === type || cat._id === categoryId;
    }
    return cat._id === categoryId || cat.type === categoryId;
  });
}

/**
 * 获取分类名称
 */
export function getCategoryName(categoryId) {
  const category = getCategoryById(categoryId);
  return category ? category.name : '';
}

/**
 * 获取分类图标
 */
export function getCategoryIcon(categoryId) {
  const category = getCategoryById(categoryId);
  return category ? category.icon : '📝';
}
