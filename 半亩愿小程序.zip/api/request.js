import config from '../config';

const { baseUrl } = config;

/**
 * @typedef {Object} ApiResponse
 * @property {number} code
 * @property {any} data
 * @property {string} [msg]
 */

/**
 * @typedef {'OPTIONS' | 'GET' | 'HEAD' | 'POST' | 'PUT' | 'DELETE' | 'TRACE' | 'CONNECT'} HttpMethod
 */

/**
 * 封装的 request 函数
 * @template T
 * @param {string} url 请求地址
 * @param {HttpMethod} [method='GET'] 请求方法
 * @param {Object} [data={}] 请求参数
 * @returns {Promise<T>}
 */
function request(url, method = 'GET', data = {}) {
  const header = {
    'content-type': 'application/json',
  };
  
  // Get token and add to header if exists
  const tokenString = wx.getStorageSync('access_token');
  if (tokenString) {
    header.Authorization = `Bearer ${tokenString}`;
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: baseUrl + url,
      method,
      data,
      header,
      success(res) {
        // 1. Check HTTP status code
        if (res.statusCode >= 200 && res.statusCode < 300) {
          // 2. Check business status code
          /** @type {ApiResponse} */
          const responseData = res.data;
          
          if (responseData && responseData.code === 200) {
            // 这里我们假设成功时直接返回 data 字段的内容
            resolve(res.data);
          } else {
            reject(responseData || { msg: '业务处理失败' });
          }
        } else {
          // HTTP Error
          reject(res);
        }
      },
      fail(err) {
        // Network error, etc.
        reject(err);
      },
    });
  });
}

export default request;
