// api/request.test.js
// 这是一个 Jest 测试用例的示例

import request from './request';

// 模拟 wx 全局对象
global.wx = {
  getStorageSync: jest.fn(),
  request: jest.fn(),
};

describe('API Request Module', () => {
  beforeEach(() => {
    // 每次测试前清空模拟调用记录
    jest.clearAllMocks();
  });

  test('应该在 header 中携带 Token', async () => {
    // 1. 准备：模拟 getStorageSync 返回一个 token
    (wx.getStorageSync as jest.Mock).mockReturnValue('fake-token-123');
    
    // 模拟 wx.request 成功回调
    (wx.request as jest.Mock).mockImplementation((options) => {
      options.success({
        statusCode: 200,
        data: { code: 200, data: 'success' }
      });
    });

    // 2. 执行：调用 request
    await request('/test');

    // 3. 验证：检查 wx.request 的调用参数中是否包含 Authorization
    expect(wx.request).toHaveBeenCalledWith(
      expect.objectContaining({
        header: expect.objectContaining({
          Authorization: 'Bearer fake-token-123',
        }),
      })
    );
  });

  test('当后端返回非 200 业务码时，应该 Reject', async () => {
    // 模拟后端返回错误码 500
    (wx.request as jest.Mock).mockImplementation((options) => {
      options.success({
        statusCode: 200,
        data: { code: 500, msg: 'Server Error' }
      });
    });

    // 验证是否抛出错误
    await expect(request('/error')).rejects.toEqual({
      code: 500,
      msg: 'Server Error'
    });
  });
});
