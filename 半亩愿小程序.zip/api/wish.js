/**
 * 心愿数据接口层
 * 负责在云开发和本地 Mock 数据之间自动切换
 */

import * as MockApi from '../mock/wish/index';

const CLOUD_COLLECTION = 'wishes';

/**
 * 检查是否应该使用云开发
 * 必须同时满足：
 * 1. 全局配置 useCloud 为 true
 * 2. wx.cloud 已定义
 */
function shouldUseCloud() {
  try {
    const app = getApp();
    return app && app.globalData && app.globalData.useCloud && wx.cloud;
  } catch (e) {
    return false;
  }
}

/**
 * 获取数据库引用
 */
function getDB() {
  return wx.cloud.database();
}

/**
 * 获取心愿列表
 */
export async function getWishList() {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const _ = db.command;
      // 获取未删除的心愿
      // 注意：云开发数据库每次最多获取 20 条，如果数据量大需要分页
      // 这里暂时获取前 20 条，后续可以优化为分页
      const res = await db.collection(CLOUD_COLLECTION)
        .where({
          isDeleted: _.neq(true) // 获取未删除的
        })
        .orderBy('createTime', 'desc')
        .get();
        
      return {
        code: 200,
        data: res.data,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 获取心愿列表失败，尝试降级:', error);
      // 如果云端失败，可以选择降级或者直接报错。
      // 为了用户体验，如果云端配置了但请求失败（如断网），
      // 这里的策略可以是：提示网络错误，或者显示本地缓存。
      // 但混用数据会导致同步问题。鉴于题目要求"确保云开发使用不了之后依旧可以正常运行"，
      // 我们这里暂时返回 Mock 数据作为兜底，但在实际生产中应谨慎混用。
      // 这里为了演示"正常运行"，我们回退到 Mock/Local。
      return MockApi.getWishList();
    }
  } else {
    return MockApi.getWishList();
  }
}

/**
 * 获取心愿详情
 */
export async function getWishDetail(id) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const res = await db.collection(CLOUD_COLLECTION).doc(id).get();
      return {
        code: 200,
        data: res.data,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 获取心愿详情失败:', error);
      return MockApi.getWishDetail(id);
    }
  } else {
    return MockApi.getWishDetail(id);
  }
}

/**
 * 创建心愿
 */
export async function createWish(wishData) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const now = new Date().toISOString();
      
      const newWish = {
        ...wishData,
        status: 'pending',
        isCompleted: false,
        isDeleted: false,
        createTime: now,
        updateTime: now,
        // _id 会由云数据库自动生成，也可以指定
        // 为了和 Mock 数据格式保持一致，我们让云数据库生成，或者如果 wishData 里有就用
      };

      const res = await db.collection(CLOUD_COLLECTION).add({
        data: newWish
      });

      return {
        code: 200,
        data: { ...newWish, _id: res._id },
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 创建心愿失败:', error);
      // 降级处理
      return MockApi.createWish(wishData);
    }
  } else {
    return MockApi.createWish(wishData);
  }
}

/**
 * 更新心愿
 */
export async function updateWish(id, wishData) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const updateData = {
        ...wishData,
        updateTime: new Date().toISOString()
      };
      
      delete updateData._id; // 不能更新 _id

      await db.collection(CLOUD_COLLECTION).doc(id).update({
        data: updateData
      });

      // 为了前端方便，返回更新后的数据（虽然 update 不返回新文档）
      // 这里简单返回成功
      return {
        code: 200,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 更新心愿失败:', error);
      return MockApi.updateWish(id, wishData);
    }
  } else {
    return MockApi.updateWish(id, wishData);
  }
}

/**
 * 删除心愿（软删除）
 */
export async function deleteWish(id) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      await db.collection(CLOUD_COLLECTION).doc(id).update({
        data: {
          isDeleted: true,
          updateTime: new Date().toISOString()
        }
      });
      return {
        code: 200,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 删除心愿失败:', error);
      return MockApi.deleteWish(id);
    }
  } else {
    return MockApi.deleteWish(id);
  }
}

/**
 * 切换心愿完成状态
 */
export async function toggleWishComplete(id, isCompleted) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const now = new Date();
      
      const updateData = {
        isCompleted: isCompleted,
        status: isCompleted ? 'completed' : 'pending',
        updateTime: now.toISOString()
      };

      if (isCompleted) {
        updateData.completedTime = now.toISOString();
        updateData.actualDate = now.toISOString().split('T')[0];
        updateData.actualTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      } else {
        updateData.completedTime = null;
        updateData.actualDate = null;
        updateData.actualTime = null;
      }

      await db.collection(CLOUD_COLLECTION).doc(id).update({
        data: updateData
      });

      return {
        code: 200,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 切换状态失败:', error);
      return MockApi.toggleWishComplete(id, isCompleted);
    }
  } else {
    return MockApi.toggleWishComplete(id, isCompleted);
  }
}

/**
 * 恢复心愿
 */
export async function restoreWish(id) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      await db.collection(CLOUD_COLLECTION).doc(id).update({
        data: {
          isDeleted: false,
          updateTime: new Date().toISOString()
        }
      });
      return {
        code: 200,
        message: 'success'
      };
    } catch (error) {
      console.error('[Cloud] 恢复心愿失败:', error);
      return MockApi.restoreWish(id);
    }
  } else {
    return MockApi.restoreWish(id);
  }
}

/**
 * 获取分类统计
 */
export async function getCategoryStatistics() {
   if (shouldUseCloud()) {
    // 统计功能在云端实现比较复杂（需要聚合），为了保持"能运行"，
    // 我们暂时先获取所有数据然后在前端统计，或者直接回退到 Mock 的逻辑
    // 如果数据量小，可以在前端拉取所有数据计算
    try {
       const db = getDB();
       const _ = db.command;
       const res = await db.collection(CLOUD_COLLECTION)
        .where({
          isDeleted: _.neq(true)
        })
        .get();
        
        const wishList = res.data;
        
        // 复用 Mock 中的统计逻辑
        // 这里我们需要把 MockApi 中的逻辑提取出来，但为了简单，
        // 我们可以在这里简单实现一下，或者直接调用 MockApi (如果它支持传入数据)
        // MockApi.getCategoryStatistics 是读 storage 的。
        // 所以我们在这里简单重写一下统计逻辑
        
        const categoryMap = {
            cat_dining: { id: 'cat_dining', name: '餐饮', icon: '🍽️', color: '#FF6B6B' },
            cat_attraction: { id: 'cat_attraction', name: '景点', icon: '🏞️', color: '#4ECDC4' },
            cat_special: { id: 'cat_special', name: '特殊事项', icon: '⭐', color: '#FFE66D' },
        };

        const statistics = {};
        Object.keys(categoryMap).forEach((catId) => {
            statistics[catId] = {
                categoryId: catId,
                categoryName: categoryMap[catId].name,
                icon: categoryMap[catId].icon,
                color: categoryMap[catId].color,
                total: 0,
                completed: 0,
                completionRate: 0,
            };
        });

        wishList.forEach((wish) => {
            const catId = wish.categoryId;
            if (statistics[catId]) {
                statistics[catId].total += 1;
                if (wish.isCompleted) {
                    statistics[catId].completed += 1;
                }
            }
        });

        Object.keys(statistics).forEach((catId) => {
            const stat = statistics[catId];
            stat.completionRate = stat.total > 0 
                ? Math.round((stat.completed / stat.total) * 100) 
                : 0;
        });

        const statisticsList = Object.values(statistics).filter(stat => stat.total > 0);

        const totalStats = {
            total: wishList.length,
            completed: wishList.filter((wish) => wish.isCompleted).length,
            completionRate: wishList.length > 0
                ? Math.round((wishList.filter((wish) => wish.isCompleted).length / wishList.length) * 100)
                : 0,
        };

        return {
            code: 200,
            data: {
                byCategory: statisticsList,
                total: totalStats,
            },
            message: 'success',
        };

    } catch(e) {
        console.error('[Cloud] 统计失败:', e);
        return MockApi.getCategoryStatistics();
    }
   } else {
       return MockApi.getCategoryStatistics();
   }
}
