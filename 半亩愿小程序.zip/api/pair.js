/**
 * 配对功能接口层
 * 负责在云开发和本地 Mock 之间切换
 */

import request from './request'; // 假设 request 用于本地 Mock (实际上 Mock 是拦截了 request)
// 引入 Mock 逻辑，如果本地模式需要直接调用 Mock 函数而不是走 request 拦截
// 这里为了简单，假设本地模式下 request 会被 mock/index.js 拦截
// 或者我们可以直接引入 mock/pair 下的函数，就像 api/wish.js 那样

import * as MockPair from '../mock/pair/index';

const PAIR_COLLECTION = 'pairs';
const INVITATION_COLLECTION = 'invitations';

/**
 * 检查是否应该使用云开发
 */
function shouldUseCloud() {
  try {
    const app = getApp();
    return app && app.globalData && app.globalData.useCloud && wx.cloud;
  } catch (e) {
    return false;
  }
}

/**
 * 获取数据库引用
 */
function getDB() {
  return wx.cloud.database();
}

/**
 * 获取配对信息
 */
export async function getPairInfo() {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const _ = db.command;
      const { OPENID } = await wx.cloud.getCloudID(); // 获取当前用户 OpenID
      
      // 查询当前用户是否在某个配对中
      // 假设配对文档结构: { _id, userA: 'openid1', userB: 'openid2', createTime }
      const res = await db.collection(PAIR_COLLECTION).where(_.or([
        { userA: OPENID },
        { userB: OPENID }
      ])).get();

      if (res.data.length > 0) {
        const pair = res.data[0];
        const partnerOpenId = pair.userA === OPENID ? pair.userB : pair.userA;
        
        // 获取伴侣信息
        // 假设用户信息存储在 users 集合
        // 这里简化处理，只返回基本信息
        return {
          code: 200,
          success: true,
          data: {
            hasPair: true,
            pairId: pair._id,
            partner: {
              uid: partnerOpenId,
              nickName: '伴侣', // 实际应查询 users 集合
              avatarUrl: ''
            },
            myInfo: {
              uid: OPENID
            },
            days: Math.floor((Date.now() - new Date(pair.createTime).getTime()) / (1000 * 60 * 60 * 24))
          }
        };
      } else {
        return {
          code: 200,
          success: true,
          data: {
            hasPair: false,
            myInfo: {
              uid: OPENID
            }
          }
        };
      }
    } catch (error) {
      console.error('[Cloud] 获取配对信息失败:', error);
      // 降级到 Mock (通过 request)
      return request('/pair/getPairInfo');
    }
  } else {
    return request('/pair/getPairInfo');
  }
}

/**
 * 生成邀请码
 */
export async function generateInvitationCode() {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const { OPENID } = await wx.cloud.getCloudID();
      
      // 生成 6 位随机邀请码
      const pairCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const expireTime = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15分钟有效
      
      // 存储到云数据库
      await db.collection(INVITATION_COLLECTION).add({
        data: {
          code: pairCode,
          creator: OPENID,
          expireTime: expireTime,
          createTime: new Date().toISOString(),
          status: 'active' // active, used, expired
        }
      });
      
      return {
        code: 200,
        success: true,
        data: {
          pairCode,
          expireTime,
          createTime: new Date().toISOString()
        }
      };
    } catch (error) {
      console.error('[Cloud] 生成邀请码失败:', error);
      return request('/pair/generateInvitationCode');
    }
  } else {
    return request('/pair/generateInvitationCode');
  }
}

/**
 * 通过邀请码绑定
 */
export async function bindByInvitationCode(invitationCode) {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const _ = db.command;
      const { OPENID } = await wx.cloud.getCloudID();
      const code = invitationCode.toUpperCase().trim();
      
      // 1. 查询邀请码
      const inviteRes = await db.collection(INVITATION_COLLECTION).where({
        code: code,
        status: 'active',
        expireTime: _.gt(new Date().toISOString()) // 未过期
      }).get();
      
      if (inviteRes.data.length === 0) {
        return {
          code: 200,
          success: false,
          data: { success: false, message: '邀请码无效或已过期' }
        };
      }
      
      const invitation = inviteRes.data[0];
      
      // 不能绑定自己生成的邀请码
      if (invitation.creator === OPENID) {
        return {
          code: 200,
          success: false,
          data: { success: false, message: '不能绑定自己的邀请码' }
        };
      }
      
      // 2. 创建配对关系
      const pairRes = await db.collection(PAIR_COLLECTION).add({
        data: {
          userA: invitation.creator,
          userB: OPENID,
          createTime: new Date().toISOString()
        }
      });
      
      // 3. 标记邀请码已使用
      await db.collection(INVITATION_COLLECTION).doc(invitation._id).update({
        data: { status: 'used' }
      });
      
      return {
        code: 200,
        success: true,
        data: {
          success: true,
          pairId: pairRes._id
        }
      };
    } catch (error) {
      console.error('[Cloud] 绑定失败:', error);
      return request('/pair/bindByInvitationCode', 'POST', { invitationCode });
    }
  } else {
    return request('/pair/bindByInvitationCode', 'POST', { invitationCode });
  }
}

/**
 * 解除配对
 */
export async function unbindPair() {
  if (shouldUseCloud()) {
    try {
      const db = getDB();
      const _ = db.command;
      const { OPENID } = await wx.cloud.getCloudID();
      
      // 查找并删除配对关系
      await db.collection(PAIR_COLLECTION).where(_.or([
        { userA: OPENID },
        { userB: OPENID }
      ])).remove();
      
      return {
        code: 200,
        success: true,
        data: { success: true }
      };
    } catch (error) {
      console.error('[Cloud] 解绑失败:', error);
      return request('/pair/unbindPair');
    }
  } else {
    return request('/pair/unbindPair');
  }
}
