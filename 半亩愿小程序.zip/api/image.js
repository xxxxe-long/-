/**
 * 图片处理接口层
 */

/**
 * 检查是否应该使用云开发
 */
function shouldUseCloud() {
  try {
    const app = getApp();
    return app && app.globalData && app.globalData.useCloud && wx.cloud;
  } catch (e) {
    return false;
  }
}

/**
 * 上传图片
 * @param {string} tempFilePath 临时文件路径
 * @param {string} cloudPath 云端存储路径 (可选)
 * @returns {Promise<string>} 上传后的路径 (云端文件ID或原始路径)
 */
export async function uploadImage(tempFilePath, cloudPath = '') {
  if (!tempFilePath) return '';

  // 如果已经是云端路径或网络路径，直接返回
  if (tempFilePath.startsWith('cloud://') || 
      tempFilePath.startsWith('http://') || 
      tempFilePath.startsWith('https://')) {
    return tempFilePath;
  }

  if (shouldUseCloud()) {
    try {
      // 如果没有指定云端路径，生成一个默认路径
      const fileName = tempFilePath.split('/').pop() || `${Date.now()}.png`;
      const finalCloudPath = cloudPath || `images/${Date.now()}-${fileName}`;

      const res = await wx.cloud.uploadFile({
        cloudPath: finalCloudPath,
        filePath: tempFilePath,
      });

      return res.fileID;
    } catch (error) {
      console.error('[Cloud] 图片上传失败:', error);
      throw error;
    }
  } else {
    // 非云开发环境，目前只能返回临时路径
    // 注意：临时路径在小程序重启后会失效
    console.warn('[Local] 图片未上传到云端，仅使用临时路径');
    return tempFilePath;
  }
}

/**
 * 批量上传图片
 * @param {Array<string>} tempFilePaths 临时文件路径数组
 * @returns {Promise<Array<string>>} 上传后的路径数组
 */
export async function uploadImages(tempFilePaths) {
  if (!tempFilePaths || !Array.isArray(tempFilePaths)) return [];
  
  const uploadTasks = tempFilePaths.map(path => uploadImage(path));
  return Promise.all(uploadTasks);
}

