/**
 * 用户资料接口层
 * 负责在云开发和本地存储之间切换
 */

const CLOUD_COLLECTION = 'users';
const STORAGE_KEY = 'user_profile';

/**
 * 检查是否应该使用云开发
 */
function shouldUseCloud() {
  try {
    const app = getApp();
    return app && app.globalData && app.globalData.useCloud && wx.cloud;
  } catch (e) {
    return false;
  }
}

/**
 * 获取用户资料
 * @returns {Promise<Object>} 用户资料对象
 */
export async function getUserProfile() {
  // 总是先尝试读取本地作为缓存，以便快速显示
  let localProfile = {};
  try {
    localProfile = wx.getStorageSync(STORAGE_KEY) || {};
  } catch (e) {
    console.error('读取本地用户资料失败:', e);
  }

  if (shouldUseCloud()) {
    try {
      const db = wx.cloud.database();
      // 获取当前用户的资料
      // 假设每个用户在 users 集合中只有一个文档
      const res = await db.collection(CLOUD_COLLECTION).get();
      
      if (res.data.length > 0) {
        const cloudProfile = res.data[0];
        // 更新本地缓存
        wx.setStorageSync(STORAGE_KEY, cloudProfile);
        return cloudProfile;
      } else {
        // 如果云端没有，尝试创建一个（如果本地有数据，则上传本地数据）
        if (Object.keys(localProfile).length > 0) {
          await db.collection(CLOUD_COLLECTION).add({
            data: {
              ...localProfile,
              createTime: new Date().toISOString(),
              updateTime: new Date().toISOString()
            }
          });
        }
        return localProfile;
      }
    } catch (error) {
      console.error('[Cloud] 获取用户资料失败，使用本地缓存:', error);
      return localProfile;
    }
  } else {
    return localProfile;
  }
}

/**
 * 更新用户资料
 * @param {Object} data 要更新的字段
 * @returns {Promise<boolean>} 是否成功
 */
export async function updateUserProfile(data) {
  try {
    // 1. 更新本地存储
    const currentProfile = wx.getStorageSync(STORAGE_KEY) || {};
    const newProfile = {
      ...currentProfile,
      ...data,
      updateTime: new Date().toISOString()
    };
    wx.setStorageSync(STORAGE_KEY, newProfile);

    // 2. 如果可用，更新云端
    if (shouldUseCloud()) {
      const db = wx.cloud.database();
      const res = await db.collection(CLOUD_COLLECTION).get();
      
      if (res.data.length > 0) {
        // 更新现有文档
        const docId = res.data[0]._id;
        await db.collection(CLOUD_COLLECTION).doc(docId).update({
          data: {
            ...data,
            updateTime: new Date().toISOString()
          }
        });
      } else {
        // 创建新文档
        await db.collection(CLOUD_COLLECTION).add({
          data: {
            ...newProfile, // 使用完整资料
            createTime: new Date().toISOString(),
            updateTime: new Date().toISOString()
          }
        });
      }
    }
    
    return true;
  } catch (error) {
    console.error('更新用户资料失败:', error);
    return false;
  }
}
