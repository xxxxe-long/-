declare namespace wx {
  interface RequestOption {
    url: string;
    data?: any;
    header?: any;
    method?: 'OPTIONS' | 'GET' | 'HEAD' | 'POST' | 'PUT' | 'DELETE' | 'TRACE' | 'CONNECT';
    dataType?: string;
    responseType?: 'text' | 'arraybuffer';
    success?: (res: RequestSuccessCallbackResult) => void;
    fail?: (res: any) => void;
    complete?: (res: any) => void;
  }

  interface RequestSuccessCallbackResult {
    data: any;
    statusCode: number;
    header: any;
    cookies: string[];
    profile?: any;
  }

  function request(option: RequestOption): any;
  function getStorageSync(key: string): any;
  function connectSocket(option: any): any;
}
