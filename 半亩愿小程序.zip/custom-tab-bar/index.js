const app = getApp();

Component({
  data: {
    value: '', // 初始值设置为空，避免第一次加载时闪烁
    list: [
      {
        icon: 'heart',
        value: 'index',
        label: '心愿',
      },
      {
        icon: 'image',
        value: 'photo-wall',
        label: '照片墙',
      },
      {
        icon: 'chart',
        value: 'statistics',
        label: '统计',
      },
      {
        icon: 'user',
        value: 'profile',
        label: '个人',
      },
    ],
  },
  lifetimes: {
    ready() {
      const pages = getCurrentPages();
      const curPage = pages[pages.length - 1];
      if (curPage) {
        // 支持带连字符的页面名，如 photo-wall
        const nameRe = /pages\/([\w-]+)\/index/.exec(curPage.route);
        if (nameRe === null) return;
        if (nameRe[1] && nameRe) {
          this.setData({
            value: nameRe[1],
          });
        }
      }
    },
  },
  methods: {
    handleChange(e) {
      const { value } = e.detail;
      wx.switchTab({ url: `/pages/${value}/index` });
    },
  },
});
