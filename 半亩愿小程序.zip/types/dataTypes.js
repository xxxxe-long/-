/**
 * 愿望清单小程序 - 数据类型定义
 * 用于代码中的类型约束和文档说明
 */

/**
 * 用户表
 * @typedef {Object} User
 * @property {string} _id - 用户ID（云数据库自动生成）
 * @property {string} openid - 微信openid（唯一标识）
 * @property {string} [unionid] - 微信unionid（可选）
 * @property {string} nickname - 昵称
 * @property {string} avatar - 头像URL
 * @property {string} [phone] - 手机号（可选）
 * @property {Date} createTime - 创建时间
 * @property {Date} updateTime - 更新时间
 */

/**
 * 用户信息快照
 * @typedef {Object} UserInfo
 * @property {string} userId - 用户ID
 * @property {string} nickname - 昵称
 * @property {string} avatar - 头像URL
 */

/**
 * 配对关系表
 * @typedef {Object} Pair
 * @property {string} _id - 配对ID
 * @property {string} user1Id - 用户1的ID
 * @property {string} user2Id - 用户2的ID
 * @property {UserInfo} user1Info - 用户1信息快照
 * @property {UserInfo} user2Info - 用户2信息快照
 * @property {string} pairCode - 配对码（用于邀请）
 * @property {'pending'|'active'|'inactive'} status - 状态
 * @property {Date} createTime - 创建时间
 * @property {Date} updateTime - 更新时间
 */

/**
 * 分类表
 * @typedef {Object} Category
 * @property {string} _id - 分类ID
 * @property {string} pairId - 所属配对ID
 * @property {string} name - 分类名称
 * @property {string} [icon] - 分类图标（可选）
 * @property {string} [color] - 分类颜色（可选）
 * @property {number} sort - 排序权重
 * @property {Date} createTime - 创建时间
 * @property {Date} updateTime - 更新时间
 */

/**
 * 地点信息
 * @typedef {Object} Location
 * @property {string} name - 地点名称
 * @property {string} address - 详细地址
 * @property {number} latitude - 纬度
 * @property {number} longitude - 经度
 * @property {string} province - 省份
 * @property {string} city - 城市
 * @property {string} district - 区县
 */

/**
 * 准备事项
 * @typedef {Object} Preparation
 * @property {string} item - 准备项名称
 * @property {boolean} isReady - 是否已准备
 * @property {string} [note] - 备注
 */

/**
 * 愿望清单项表
 * @typedef {Object} WishItem
 * @property {string} _id - 愿望项ID
 * @property {string} pairId - 所属配对ID
 * @property {string} categoryId - 分类ID
 * @property {string} title - 标题（必填）
 * @property {string} [description] - 描述（可选）
 * @property {'pending'|'completed'|'cancelled'} status - 状态
 * @property {boolean} isCompleted - 是否已完成（冗余字段）
 * @property {Date} [completedTime] - 完成时间
 * @property {Date} [plannedDate] - 计划日期（可选）
 * @property {string} [plannedTime] - 计划时间（可选，如 "14:00"）
 * @property {Date} [actualDate] - 实际完成日期（可选）
 * @property {string} [actualTime] - 实际完成时间（可选）
 * @property {Location} [location] - 地点信息
 * @property {Preparation[]} [preparations] - 准备事项列表
 * @property {string[]} [tags] - 标签（可选）
 * @property {string[]} [images] - 图片URL列表（可选）
 * @property {string} [notes] - 备注（可选）
 * @property {number} [priority] - 优先级：1-5（1最高，5最低）
 * @property {string} createdBy - 创建者用户ID
 * @property {string} createdByName - 创建者昵称
 * @property {string} [completedBy] - 完成者用户ID（可选）
 * @property {string} [completedByName] - 完成者昵称（可选）
 * @property {Date} createTime - 创建时间
 * @property {Date} updateTime - 更新时间
 */

/**
 * 评论/记录表
 * @typedef {Object} Comment
 * @property {string} _id - 评论ID
 * @property {string} wishItemId - 关联的愿望项ID
 * @property {string} userId - 评论者用户ID
 * @property {string} userName - 评论者昵称
 * @property {string} userAvatar - 评论者头像
 * @property {string} content - 评论内容
 * @property {string[]} [images] - 评论图片（可选）
 * @property {Date} createTime - 创建时间
 * @property {Date} updateTime - 更新时间
 */

/**
 * 分类类型枚举
 */
export const CategoryType = {
  DINING: 'dining',           // 餐饮
  ATTRACTION: 'attraction',   // 景点
  SPECIAL: 'special',         // 特殊事项
  OTHER: 'other'              // 其他
};

/**
 * 分类名称映射
 */
export const CategoryNameMap = {
  [CategoryType.DINING]: '餐饮',
  [CategoryType.ATTRACTION]: '景点',
  [CategoryType.SPECIAL]: '特殊事项',
  [CategoryType.OTHER]: '其他'
};

/**
 * 状态枚举
 */
export const Status = {
  PENDING: 'pending',       // 待完成
  COMPLETED: 'completed',   // 已完成
  CANCELLED: 'cancelled'    // 已取消
};

/**
 * 配对状态枚举
 */
export const PairStatus = {
  PENDING: 'pending',       // 待确认
  ACTIVE: 'active',         // 活跃
  INACTIVE: 'inactive'      // 非活跃
};

/**
 * 优先级枚举
 */
export const Priority = {
  HIGHEST: 1,   // 最高
  HIGH: 2,      // 高
  MEDIUM: 3,    // 中
  LOW: 4,       // 低
  LOWEST: 5     // 最低
};

/**
 * 默认分类配置
 */
export const DefaultCategories = [
  {
    name: CategoryNameMap[CategoryType.DINING],
    type: CategoryType.DINING,
    icon: '🍽️',
    color: '#FF6B6B',
    sort: 1
  },
  {
    name: CategoryNameMap[CategoryType.ATTRACTION],
    type: CategoryType.ATTRACTION,
    icon: '🏞️',
    color: '#00CEC9', // 青色（保持原色）
    sort: 2
  },
  {
    name: CategoryNameMap[CategoryType.SPECIAL],
    type: CategoryType.SPECIAL,
    icon: '⭐',
    color: '#FFE66D',
    sort: 3
  }
];
